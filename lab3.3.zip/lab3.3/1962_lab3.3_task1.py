#an electricity billing system must collect accurate consumer data,reading previous units,current units,type of customer.calculate units consumed and implement logic directly in main program.don't calcualte bill amount.
def calculate_units_consumed(previous_units, current_units):
    return current_units - previous_units# Function to calculate units consumed
def main():
    print("Electricity Billing System")# Collect consumer data
    consumer_name = input("Enter Consumer Name: ")  # Input consumer name
    previous_units = int(input("Enter Previous Units: "))# Input previous units
    current_units = int(input("Enter Current Units: "))# Input current units
    customer_type = input("Enter Customer Type (Residential/Commercial): ")# Input customer type

    units_consumed = calculate_units_consumed(previous_units, current_units)# Calculate units consumed

    print("\n--- Billing Details ---")# Display billing details
    print(f"Consumer Name: {consumer_name}")# Print consumer name
    print(f"Customer Type: {customer_type}")# Print customer type
    print(f"Previous Units: {previous_units}")# Print previous units
    print(f"Current Units: {current_units}")# Print current units
    print(f"Units Consumed: {units_consumed}")# Print units consumed
if __name__ == "__main__":
    main()