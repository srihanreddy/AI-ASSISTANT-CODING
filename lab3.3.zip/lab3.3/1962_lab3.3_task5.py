#an electricity billing system must collect accurate consumer data,reading previous units,current units,fixed charges,customer charges,and electricity duty rates.
#The final electricity bill must present all values clearly.

#Develop the final Python application to:
# Calculate total bill:
# Total Bill = EC + FC + CC + ED
# Display:
#Energy Charges (EC)
# Fixed Charges (FC)(a constant value)
# Customer Charges (CC)(a constant value)
# Electricity Duty (ED)(a percentage of the sum of EC, FC, and CC)
# Total Bill Amount
def calculate_energy_charges(previous_units, current_units, rate_per_unit):
    return (current_units - previous_units) * rate_per_unit
def calculate_electricity_duty(ec, fc, cc, duty_rate):
    return (ec + fc + cc) * duty_rate / 100
def main():
    # Constants
    FIXED_CHARGES = 50.0  # Fixed Charges (FC)
    CUSTOMER_CHARGES = 30.0  # Customer Charges (CC)
    DUTY_RATE = 5.0  # Electricity Duty Rate (ED) in percentage
    RATE_PER_UNIT = 2.0  # Rate per unit of electricity

    # Input from user
    previous_units = float(input("Enter previous meter reading (in units): "))
    current_units = float(input("Enter current meter reading (in units): "))

    # Calculate Energy Charges (EC)
    energy_charges = calculate_energy_charges(previous_units, current_units, RATE_PER_UNIT)

    # Calculate Electricity Duty (ED)
    electricity_duty = calculate_electricity_duty(energy_charges, FIXED_CHARGES, CUSTOMER_CHARGES, DUTY_RATE)

    # Calculate Total Bill
    total_bill = energy_charges + FIXED_CHARGES + CUSTOMER_CHARGES + electricity_duty

    # Display the bill details
    print("\nElectricity Bill Details:")
    print(f"Energy Charges (EC): ${energy_charges:.2f}")
    print(f"Fixed Charges (FC): ${FIXED_CHARGES:.2f}")
    print(f"Customer Charges (CC): ${CUSTOMER_CHARGES:.2f}")
    print(f"Electricity Duty (ED): ${electricity_duty:.2f}")
    print(f"Total Bill Amount: ${total_bill:.2f}")
if __name__ == "__main__":
    main()