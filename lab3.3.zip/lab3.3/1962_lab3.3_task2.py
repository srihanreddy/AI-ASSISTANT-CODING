#an electricity billing system must collect accurate consumer data,reading previous units,current units,type of customer and calculate energy charges.
def calculate_units_consumed(previous_units, current_units):
    return current_units - previous_units  # Function to calculate units consumed
def calculate_bill_amount(units_consumed, customer_type):
    #add a customer type "industrial" with different rates.
    if customer_type.lower() == "industrial":
        if units_consumed <= 100:
            return units_consumed * 1.2
        elif units_consumed <= 300:
            return (100 * 1.2) + (units_consumed - 100) * 1.8
        else:
            return (100 * 1.2) + (200 * 1.8) + (units_consumed - 300) * 2.5
    if customer_type.lower() == "residential":
        if units_consumed <= 100:
            return units_consumed * 0.5
        elif units_consumed <= 300:
            return (100 * 0.5) + (units_consumed - 100) * 0.75
        else:
            return (100 * 0.5) + (200 * 0.75) + (units_consumed - 300) * 1.0
    elif customer_type.lower() == "commercial":
        if units_consumed <= 100:
            return units_consumed * 1.0
        elif units_consumed <= 300:
            return (100 * 1.0) + (units_consumed - 100) * 1.5
        else:
            return (100 * 1.0) + (200 * 1.5) + (units_consumed - 300) * 2.0
    else:
        return ("invalid user type")  # Invalid customer type
def main():
    print("Electricity Billing System")  # Collect consumer data
    consumer_name = input("Enter Consumer Name: ")  # Input consumer name
    previous_units = int(input("Enter Previous Units: "))  # Input previous units
    current_units = int(input("Enter Current Units: "))  # Input current units
    customer_type = input("Enter Customer Type (Residential/Commercial/Industrial): ")  # Input customer type

    units_consumed = calculate_units_consumed(previous_units, current_units)  # Calculate units consumed
    bill_amount = calculate_bill_amount(units_consumed, customer_type)  # Calculate bill amount

    print("\n--- Billing Details ---")  # Display billing details
    print(f"Consumer Name: {consumer_name}")  # Print consumer name
    print(f"Customer Type: {customer_type}")  # Print customer type
    print(f"Previous Units: {previous_units}")  # Print previous units
    print(f"Current Units: {current_units}")  # Print current units
    print(f"Units Consumed: {units_consumed}")  # Print units consumed
    print(f"Bill Amount: {bill_amount}")  # Print bill amount
if __name__ == "__main__":
    main()