#an electricity billing system must collect accurate consumer data,reading previous units,current units,type of customer and calculate energy charges and fixed charges
#Add electricity duty calculation”
# “Improve billing accuracy
def calculate_bill(previous_units, current_units, customer_type):
    # Define rates and fixed charges
    rates = {
        'residential': 0.12,  # per unit
        'commercial': 0.15,   # per unit
        'industrial': 0.10     # per unit
    }
    
    fixed_charges = {
        'residential': 5.00,
        'commercial': 10.00,
        'industrial': 20.00
    }
    
    electricity_duty_rate = 0.05  # 5% duty on energy charges

    # Calculate consumed units
    consumed_units = current_units - previous_units
    if consumed_units < 0:
        raise ValueError("Current units must be greater than or equal to previous units.")

    # Get rate and fixed charge based on customer type
    if customer_type not in rates:
        raise ValueError("Invalid customer type. Must be 'residential', 'commercial', or 'industrial'.")

    rate_per_unit = rates[customer_type]
    fixed_charge = fixed_charges[customer_type]

    # Calculate energy charges
    energy_charges = consumed_units * rate_per_unit

    # Calculate electricity duty
    electricity_duty = energy_charges * electricity_duty_rate

    # Total bill calculation
    total_bill = energy_charges + fixed_charge + electricity_duty

    return {
        'consumed_units': consumed_units,
        'energy_charges': round(energy_charges, 2),
        'fixed_charge': round(fixed_charge, 2),
        'electricity_duty': round(electricity_duty, 2),
        'total_bill': round(total_bill, 2)
    }
 #print electricity duty and fixed charges on the bill
if __name__ == "__main__":
    # Sample input
    previous_units = int(input("Enter previous meter reading: "))
    current_units = int(input("Enter current meter reading: "))
    customer_type = input("Enter customer type (residential/commercial/industrial): ").strip().lower()

    try:
        bill_details = calculate_bill(previous_units, current_units, customer_type)
        print("\n--- Electricity Bill ---")
        print(f"Consumed Units: {bill_details['consumed_units']} units")
        print(f"Energy Charges: ${bill_details['energy_charges']}")
        print(f"Fixed Charge: ${bill_details['fixed_charge']}")
        print(f"Electricity Duty: ${bill_details['electricity_duty']}")
        print(f"Total Bill Amount: ${bill_details['total_bill']}")
    except ValueError as e:
        print(f"Error: {e}")
    
